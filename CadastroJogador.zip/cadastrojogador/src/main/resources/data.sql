CREATE database bd_jogador;

use bd_jogador;
3
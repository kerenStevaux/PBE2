// Quando clicar no botão "Cadastrar"

document.addEventListener("DOMContentLoaded", function() {

	// Seleciona o formulário pelo ID
	const form = document.getElementById("formCadastroJogador");

	// Adiciona um evento de submit no formulário
	form.addEventListener("submit", function(event) {
		event.preventDefault(); // Impede o envio padrão do formulário

		const nomeConst = document.getElementById('Nome Jogo Formulario').value;
		const anoConst = document.getElementById('Ano Lançamento Formulario').value;

		// Enviar para a API
		fetch('http://localhost:8080/jogadores', {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify(
				{
					nomeJogo: nomeConst,
					anoLancamento: anoConst,
				})
		});

		document.getElementById('formCadastro').reset();
		location.reload();

	});

	// Quando a página carregar
	window.onload = function() {
		// Buscar pessoinhas da API e mostrar na tabela
		fetch('http://localhost:8080/jogadores')
			.then(res => res.json())
			.then(pessoinhas => {
				const tabela = document.getElementById('tabelaJogos').querySelector('tbody');
				pessoinhas.forEach(p => {
					const linha = tabela.insertRow();
					linha.insertCell(0).textContent = p.nomeJogo;
					linha.insertCell(1).textContent = p.anoLancamento;
				});
			});
	};
});
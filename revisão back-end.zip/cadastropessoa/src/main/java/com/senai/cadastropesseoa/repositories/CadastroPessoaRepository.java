package com.senai.cadastropesseoa.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.senai.cadastropesseoa.entities.CadastroPessoa;

public interface CadastroPessoaRepository extends JpaRepository<CadastroPessoa, Long>{

}

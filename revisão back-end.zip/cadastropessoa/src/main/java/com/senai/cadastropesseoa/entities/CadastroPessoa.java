package com.senai.cadastropesseoa.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "bd_cadastro_pessoa")
public class CadastroPessoa {

	//atributo
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idPessoa;
	
	@Column(name = "nome_pessoa")
	private String nomePessoaAtributo;
	
	@Column(name = "idade")
	private int idadePessoaAtributo;
	
	//construtores
	CadastroPessoa(){
		
	}
	
	CadastroPessoa(Long idPessoaParametro, String nomePessoaParametro, int idadePessoaParametro){
		this.idPessoa = idPessoaParametro;
		this.nomePessoaAtributo = nomePessoaParametro;
		this.idadePessoaAtributo = idadePessoaParametro;
	}
	
	//gettes and setters
		public Long getId() {
			return idPessoa;
		}
		
		public void setId(Long idPessoaParametroSet) {
			this.idPessoa = idPessoaParametroSet;
		}
		
		public String getNomePessoaAtributo() {
			return nomePessoaAtributo;
		}
		
		public void setNomePessoaAtributo(String nomePessoaParametroSet) {
			this.nomePessoaAtributo = nomePessoaParametroSet;
		}
		
		public int getIdadePessoaAtributo() {
			return idadePessoaAtributo;
		}
		
		public void setIdadePessoaAtributo(int idadePessoaParametroSet) {
			this.idadePessoaAtributo = idadePessoaParametroSet;
		}
		
	
	
	
	
	
	
	
	
	
}

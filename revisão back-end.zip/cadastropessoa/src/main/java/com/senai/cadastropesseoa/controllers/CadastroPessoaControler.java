package com.senai.cadastropesseoa.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.senai.cadastropesseoa.entities.CadastroPessoa;
import com.senai.cadastropesseoa.services.CadastroPessoaService;

@RestController
@RequestMapping("/cadastropessoa")
public class CadastroPessoaControler {

	@Autowired
	private CadastroPessoaService objetoCadastroPessoaService;
	
	@PostMapping
	public CadastroPessoa criarNovoCadastroPessoa(@RequestBody CadastroPessoa cadastroPessoaPrametro) {
		return objetoCadastroPessoaService.salvarCadastroPessoa(cadastroPessoaPrametro);
	}
	
	@GetMapping
	public List<CadastroPessoa> buscarTodoCadastroPessoa(){
		return objetoCadastroPessoaService.buscarTodoCadastroPessoa();
	}
}

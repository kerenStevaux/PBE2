let index = 0;

        function moverCarrossel(direcao) {
            const items = document.querySelectorAll('.carrossel-item');
            const totalItems = items.length;

            index = (index + direcao + totalItems) % totalItems;
            const container = document.querySelector('.carrossel-container');
            container.style.transform = `translateX(-${index * 100}%)`;
        }